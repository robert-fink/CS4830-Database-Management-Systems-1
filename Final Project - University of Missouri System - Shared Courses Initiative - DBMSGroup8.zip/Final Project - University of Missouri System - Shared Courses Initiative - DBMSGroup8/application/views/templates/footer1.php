<!--Put footer info here-->
        <div class="container">
            <p style="padding-left: 30px;">Copyright &copy; 2003-<?php echo date("Y"); ?> The Curators of the University of Missouri. All rights reserved.</p>

            <p style="padding-left: 30px;"><a href="/ums/copyright/">DMCA Policy</a> | <a href="/help/help-accessibility">Accessibility</a> | <a href="/ums/rules/collected_rules/personnel/ch320/320.010_Equal_Employment_Opportunity_Program/">An equal opportunity/affirmative action institution</a></p>
        </div>     
</html>
<script type="text/javascript" class="init">
  $(document).ready(function() {
    $('.datatable').dataTable();
  } );          
</script>

